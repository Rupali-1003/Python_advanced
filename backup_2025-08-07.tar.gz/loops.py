list_of_person = ["ram" , "shyam" , "tanu" , "ankit" , "harsh"]

for person in list_of_person:
    print(person)
    if person == "ankit":
        print("I love you")
    else:
        print("You are a friend of mine")
        
