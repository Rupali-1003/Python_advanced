import datetime

def showdate():
    return datetime.datetime.today()


date = showdate()  # if you are returning a value in function , so you have to catch that value here , for this use a variable to store the result
print(date)