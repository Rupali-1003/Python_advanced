num1=input("enter your first number: ")
num2=input("enter your second number: ")
choice=input("enter your choice (add/subtract/multiply/didvide): ")

if choice == "add":
    result = float(num1) + float(num2)
elif choice == "subtract":
    result = float(num1) - float(num2)
elif choice == "multiply":
    result = float(num1) * float(num2)
elif choice == "divide":
    result = float(num1) / float(num2)
else:
    result = "Invalid choice"
print("The result is: " + str(result))
