list_of_fruits = ["apple" , "banana" , "mango" ,"orange" , "grapes"]


list_of_fruits.append("pineapple")
list_of_fruits.insert(3, "kiwi")

print (list_of_fruits)
print(len(list_of_fruits))