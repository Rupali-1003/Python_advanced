

#print(os.system('df -h'))      # these command can only run in mac or linux not in windows
#print(os.system('uptime'))

#import os

#print(os.system('wmic logicaldisk get size,freespace,caption')) #command to check disk size in windows

import shutil
import time
import psutil

# Uptime
boot_time = psutil.boot_time()
uptime_seconds = time.time() - boot_time
uptime_hours = uptime_seconds // 3600
uptime_minutes = (uptime_seconds % 3600) // 60
print(f"System Uptime: {int(uptime_hours)} hours, {int(uptime_minutes)} minutes")
print(" ")

# Load average (not available on Windows, so show CPU usage over 1, 5, 15 seconds)
print("Simulated Load Average (CPU %):")
print(f"1 sec: {psutil.cpu_percent(interval=1)}%")
print(f"5 sec: {psutil.cpu_percent(interval=5)}%")
print(f"15 sec: {psutil.cpu_percent(interval=15)}%")
print(" ")

cpu_percent = psutil.cpu_percent(interval=1)
print(f"CPU Usage: {cpu_percent}%")
print(" ")

memory = psutil.virtual_memory()
print(f"Total RAM: {memory.total // (2**20)} MB")
print(f"Available RAM: {memory.available // (2**20)} MB")
print(f"Used RAM: {memory.used // (2**20)} MB")
print(f"RAM Usage: {memory.percent}%")
print(" ")

total, used, free = shutil.disk_usage("C:/")
print(f"Total: {total // (2**30)} GiB")
print(f"Used: {used // (2**30)} GiB")
print(f"Free: {free // (2**30)} GiB")