import os

def execute(command):
    print(os.system(command))

execute("df -h")

def date(command):
    print(os.system(command))

date("date")

def check_uptime(command):                 
    # can also use return then sysntax will be return os.system(command)
    print(os.system(command))

check_uptime("uptime")
