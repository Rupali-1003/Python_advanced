name=input("enter your name: ")
print("Hello, " + name + "! Welcome to the demo program.")